#include "stm32f10x.h"

uint16_t adc_value = 0;
float yanwu = 0.0f;
uint16_t exitFlag = 1; 
uint8_t shu = 5;


#define LEDblue_PORT GPIOC
#define LEDblue_PIN GPIO_Pin_0

#define LEDgreen_PORT GPIOC
#define LEDgreen_PIN GPIO_Pin_1

#define buzzer_PORT GPIOC
#define buzzer_PIN GPIO_Pin_13

#define SEG_A GPIO_Pin_0
#define SEG_B GPIO_Pin_1
#define SEG_C GPIO_Pin_2
#define SEG_D GPIO_Pin_3
#define SEG_E GPIO_Pin_4
#define SEG_F GPIO_Pin_5
#define SEG_G GPIO_Pin_6
#define SEG_DP GPIO_Pin_7
#define DIGIT_ONES GPIO_Pin_8


void delay(unsigned int Number);
void Delay_us(unsigned int us);
void Delay_ms(unsigned int ms);

void LEDblue_INIT(void);
void LEDblue_on(void);
void LEDblue_off(void);

void LEDgreen_INIT(void);
void LEDgreen_on(void);
void LEDgreen_off(void);

void buzzer_INIT(void);
void buzzer_on(void);
void buzzer_off(void);

void display_Init(void);
void TIM2_Config(void);
void displaydaoshi(uint8_t shu);
void TIM2_IRQHandler(void);

void ADC1_Configuration(void);
void button_Init(void);
void NVIC_Configuration(void);
void EXTI_Configuration(void);

int main(void)
{
    LEDblue_INIT();
	  LEDgreen_INIT();
	  buzzer_INIT();
    display_Init();
		button_Init();
    NVIC_Configuration();  
    EXTI_Configuration();
		ADC1_Configuration();
	
	  while(1)
		{ 
		 adc_value = ADC_GetConversionValue(ADC1);
		 yanwu = ((float)adc_value / 4095.0) * 100.0;
			if(yanwu >70.0f)
        {
					for(shu=5;shu > 0;shu--)
					{
						displaydaoshi(shu);
						Delay_ms(100000);
					}
					TIM2_Config();
					buzzer_on();
					LEDblue_on();
					LEDgreen_on();
					if(exitFlag)
						{	
						buzzer_off();
					  GPIO_ResetBits(GPIOC, GPIO_Pin_13);
					//		LEDblue_on();
					//	LEDgreen_on();
						}	
				}
			//if(yanwu <70.0f){
				//displaydaoshi(0);
			//	buzzer_off();
			//	LEDblue_off();
			//	LEDgreen_off();}
		}
}
void ADC1_Configuration(void)
{
    ADC_InitTypeDef ADC_InitStructure;
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1 | RCC_APB2Periph_GPIOB, ENABLE);
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_Init(GPIOB, &GPIO_InitStructure);
		GPIO_SetBits(GPIOB,GPIO_Pin_0);

    ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;
    ADC_InitStructure.ADC_ScanConvMode = DISABLE;
    ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;
    ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;
    ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;
    ADC_InitStructure.ADC_NbrOfChannel = 1;
    ADC_Init(ADC1, &ADC_InitStructure);
    ADC_RegularChannelConfig(ADC1, ADC_Channel_8, 1, ADC_SampleTime_55Cycles5);

    ADC_Cmd(ADC1, ENABLE);
    while(ADC_GetResetCalibrationStatus(ADC1));
    ADC_StartCalibration(ADC1);
    while(ADC_GetCalibrationStatus(ADC1));
    ADC_SoftwareStartConvCmd(ADC1, ENABLE);
}
void display_Init(){
	  GPIO_InitTypeDef GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOA, ENABLE);
	  GPIO_InitStructure.GPIO_Pin=SEG_A|SEG_B|SEG_C|SEG_D|SEG_E|SEG_F|SEG_G|SEG_DP;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
		GPIO_SetBits(GPIOA, SEG_A | SEG_B | SEG_C | SEG_D | SEG_E | SEG_F | SEG_G | SEG_DP);
	
	  GPIO_InitStructure.GPIO_Pin=DIGIT_ONES;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);
		GPIO_SetBits(GPIOA,DIGIT_ONES);
}

void displaydaoshi(uint8_t shu){
    uint8_t segmentMap[10] = {0x3F,0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F };
		uint8_t ones=shu;
		GPIO_Write(GPIOA,segmentMap[ones]);
    Delay_ms(10000);
}
void TIM2_Config()
{
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
		
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
		TIM_DeInit(TIM2);
	
    TIM_TimeBaseStructure.TIM_Period = 100-1;
    TIM_TimeBaseStructure.TIM_Prescaler = 720-1;  
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);

    TIM_ITConfig(TIM2, TIM_IT_Update, ENABLE);
	
		NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);  
    NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);

    TIM_Cmd(TIM2, ENABLE);
		
}
void TIM2_IRQHandler() {
    if (TIM_GetITStatus(TIM2, TIM_IT_Update) == SET) {
			TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
						displaydaoshi(0);
    }
}
void buzzer_INIT()
{
		GPIO_InitTypeDef GPIO_InitStruct;

		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
		
		GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP; 
		GPIO_InitStruct.GPIO_Pin = GPIO_Pin_13;
		GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz; 
		GPIO_Init(GPIOC, &GPIO_InitStruct);
	
		GPIO_SetBits(GPIOC, GPIO_Pin_13);
}
void buzzer_on()
{
	GPIO_SetBits(GPIOC, GPIO_Pin_13);
}
void buzzer_off()
{
	GPIO_ResetBits(GPIOC, GPIO_Pin_13);	
}
void LEDblue_INIT(){
	  GPIO_InitTypeDef GPIO_InitStruct;
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
		GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP; 
		GPIO_InitStruct.GPIO_Pin = GPIO_Pin_0;
		GPIO_InitStruct.GPIO_Speed = GPIO_Speed_10MHz; 
		GPIO_Init(GPIOC, &GPIO_InitStruct);
		
		GPIO_SetBits(GPIOC, GPIO_Pin_0);

}
void LEDblue_on(){
    GPIO_ResetBits(GPIOC, GPIO_Pin_0);
}
void LEDblue_off(){
    GPIO_SetBits(GPIOC, GPIO_Pin_0);
}
void LEDgreen_INIT(){
	  GPIO_InitTypeDef GPIO_InitStruct;
		RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
		GPIO_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP; 
		GPIO_InitStruct.GPIO_Pin = GPIO_Pin_1;
		GPIO_InitStruct.GPIO_Speed = GPIO_Speed_10MHz; 
		GPIO_Init(GPIOC, &GPIO_InitStruct);
		
		GPIO_SetBits(GPIOC, GPIO_Pin_1);

}
void LEDgreen_on(){
    GPIO_ResetBits(GPIOC, GPIO_Pin_1);
}
void LEDgreen_off(){
    GPIO_SetBits(GPIOC, GPIO_Pin_1);
}
void button_Init(void){
	   GPIO_InitTypeDef GPIO_InitStruct;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
    
    GPIO_InitStruct.GPIO_Mode = GPIO_Mode_IPU;  
    GPIO_InitStruct.GPIO_Pin = GPIO_Pin_2;  
    GPIO_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOC, &GPIO_InitStruct);

}
void NVIC_Configuration() {
    NVIC_InitTypeDef NVIC_InitStructure;
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);  
    NVIC_InitStructure.NVIC_IRQChannel = EXTI2_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}
void EXTI_Configuration(void) {
    EXTI_InitTypeDef EXTI_InitStructure;
    GPIO_EXTILineConfig(GPIO_PortSourceGPIOC, GPIO_PinSource2);
    EXTI_InitStructure.EXTI_Line = EXTI_Line2;
    EXTI_InitStructure.EXTI_Mode = EXTI_Mode_Interrupt;
    EXTI_InitStructure.EXTI_Trigger = EXTI_Trigger_Falling;
    EXTI_InitStructure.EXTI_LineCmd = ENABLE;
    EXTI_Init(&EXTI_InitStructure);
}
 
void EXTI2_IRQHandler(void) {
    if (EXTI_GetITStatus(EXTI_Line2) != RESET) {
        exitFlag = !exitFlag;
				GPIO_SetBits(GPIOC, GPIO_Pin_13);
        EXTI_ClearITPendingBit(EXTI_Line2);
    }
}
void Delay_us(unsigned int us) {
    
   SysTick->LOAD = 72 * us; 
                             
                             
    SysTick->VAL = 0x00;     
    
    SysTick->CTRL = 0x00000005; 
    
    while(!(SysTick->CTRL & 0x00010000)); 
    
    SysTick->CTRL = 0x00000004; 
}
void Delay_ms(unsigned int ms) {
    while(ms--)
	{
		Delay_us(1000);
	}
}


